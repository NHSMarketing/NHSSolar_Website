<?php

	$host = 'smtp.nhs.com.br';
	$port = 25;
	$email_falecom = 'falecom@nhs.com';
	$senha_falecom = 'falecomnhs';
	$from_falecom = $email_falecom;
	$to_falecom = 'falecom@nhs.com.br';
	$email_marketing = 'marketing@nhs.com';
	$senha_marketing = 'marketingnhs';
	$from_marketing = $email_marketing;
	$to_marketing = 'marketing@nhs.com.br';
